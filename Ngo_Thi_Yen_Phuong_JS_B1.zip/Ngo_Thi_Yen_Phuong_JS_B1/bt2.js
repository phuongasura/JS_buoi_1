//TÍNH GIÁ TRỊ TRUNG BÌNH
var num_1 = 4;
var num_2 = 5;
var num_3 = 7;
var num_4 = 3;
var num_5 = 9;
var tb = 0;
tb = (num_1+num_2+num_3+num_4+num_5)/5;
console.log("Giá trị trung bình là: " + tb);