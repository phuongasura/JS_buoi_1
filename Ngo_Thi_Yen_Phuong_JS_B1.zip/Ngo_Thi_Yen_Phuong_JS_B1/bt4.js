//TÍNH DIỆN TÍCH, CHU VI HÌNH CHỮ NHẬT
var chieuDai = 6;
var chieuRong = 5
var dienTich = chieuDai*chieuRong;
var chuVi = (chieuDai + chieuRong)*2;
console.log("Diện tích HCN là: " + dienTich);
console.log("Chu vi HCN là: " + chuVi);